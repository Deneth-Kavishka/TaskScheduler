#!/bin/bash

echo "Starting MediVault application..."

node server.js &

cd frontend && npm run dev
