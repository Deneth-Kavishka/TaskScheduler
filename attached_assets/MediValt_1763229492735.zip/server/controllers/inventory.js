const Inventory = require("../models/Inventory");
const Medicine = require("../models/Medicine");
const ErrorResponse = require("../utils/errorResponse");

// @desc    Get all inventory items
// @route   GET /api/inventory
// @access  Private (Pharmacist, Admin)
exports.getInventoryItems = async (req, res, next) => {
  try {
    let query = {};

    // Filter by medicine
    if (req.query.medicine) {
      query.medicine = req.query.medicine;
    }

    // Filter by status
    if (req.query.status) {
      query.status = req.query.status;
    }

    // Filter by low stock
    if (req.query.lowStock === "true") {
      query.$expr = {
        $lt: ["$quantity.available", "$reorderLevel"],
      };
    }

    // Filter by expiring soon (next 30 days)
    if (req.query.expiringSoon === "true") {
      const today = new Date();
      const thirtyDaysFromNow = new Date();
      thirtyDaysFromNow.setDate(today.getDate() + 30);

      query.expiryDate = {
        $gte: today,
        $lte: thirtyDaysFromNow,
      };
    }

    // Filter by expired
    if (req.query.expired === "true") {
      query.expiryDate = { $lt: new Date() };
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Inventory.countDocuments(query);

    // Execute query
    const inventory = await Inventory.find(query)
      .populate("medicine", "name genericName drugClass strength")
      .populate("createdBy", "firstName lastName role")
      .populate("updatedBy", "firstName lastName role")
      .sort({ expiryDate: 1 })
      .skip(startIndex)
      .limit(limit);

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit,
      };
    }

    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit,
      };
    }

    res.status(200).json({
      success: true,
      count: inventory.length,
      pagination,
      data: inventory,
    });
  } catch (error) {
    console.error("Get inventory error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving inventory",
    });
  }
};

// @desc    Get single inventory item
// @route   GET /api/inventory/:id
// @access  Private (Pharmacist, Admin)
exports.getInventoryItem = async (req, res, next) => {
  try {
    const item = await Inventory.findById(req.params.id)
      .populate("medicine")
      .populate("createdBy", "firstName lastName role")
      .populate("updatedBy", "firstName lastName role");

    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Inventory item not found",
      });
    }

    res.status(200).json({
      success: true,
      data: item,
    });
  } catch (error) {
    console.error("Get inventory item error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving inventory item",
    });
  }
};

// @desc    Create new inventory item
// @route   POST /api/inventory
// @access  Private (Pharmacist, Admin)
exports.createInventoryItem = async (req, res, next) => {
  try {
    // Add user to req.body
    req.body.createdBy = req.user.id;
    req.body.updatedBy = req.user.id;

    // Generate inventory ID
    const inventoryCount = await Inventory.countDocuments();
    req.body.inventoryId = `INV${String(inventoryCount + 1).padStart(6, "0")}`;

    // Verify medicine exists
    const medicine = await Medicine.findById(req.body.medicine);
    if (!medicine) {
      return res.status(404).json({
        success: false,
        message: "Medicine not found",
      });
    }

    const inventoryItem = await Inventory.create(req.body);

    res.status(201).json({
      success: true,
      message: "Inventory item created successfully",
      data: inventoryItem,
    });
  } catch (error) {
    console.error("Create inventory item error:", error);
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(", "),
      });
    }
    res.status(500).json({
      success: false,
      message: "Server error creating inventory item",
    });
  }
};

// @desc    Update inventory item
// @route   PUT /api/inventory/:id
// @access  Private (Pharmacist, Admin)
exports.updateInventoryItem = async (req, res, next) => {
  try {
    let item = await Inventory.findById(req.params.id);

    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Inventory item not found",
      });
    }

    // Add updated by user
    req.body.updatedBy = req.user.id;

    item = await Inventory.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    })
      .populate("medicine")
      .populate("updatedBy", "firstName lastName role");

    res.status(200).json({
      success: true,
      message: "Inventory item updated successfully",
      data: item,
    });
  } catch (error) {
    console.error("Update inventory item error:", error);
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(", "),
      });
    }
    res.status(500).json({
      success: false,
      message: "Server error updating inventory item",
    });
  }
};

// @desc    Delete inventory item
// @route   DELETE /api/inventory/:id
// @access  Private (Admin)
exports.deleteInventoryItem = async (req, res, next) => {
  try {
    const item = await Inventory.findById(req.params.id);

    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Inventory item not found",
      });
    }

    await item.deleteOne();

    res.status(200).json({
      success: true,
      message: "Inventory item deleted successfully",
      data: {},
    });
  } catch (error) {
    console.error("Delete inventory item error:", error);
    res.status(500).json({
      success: false,
      message: "Server error deleting inventory item",
    });
  }
};

// @desc    Get inventory statistics
// @route   GET /api/inventory/stats
// @access  Private (Pharmacist, Admin)
exports.getInventoryStats = async (req, res, next) => {
  try {
    const today = new Date();
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(today.getDate() + 30);

    const stats = await Inventory.aggregate([
      {
        $facet: {
          totalItems: [{ $count: "count" }],
          lowStock: [
            {
              $match: {
                $expr: {
                  $lt: ["$quantity.available", "$reorderLevel"],
                },
              },
            },
            { $count: "count" },
          ],
          expiringSoon: [
            {
              $match: {
                expiryDate: {
                  $gte: today,
                  $lte: thirtyDaysFromNow,
                },
              },
            },
            { $count: "count" },
          ],
          expired: [
            {
              $match: {
                expiryDate: { $lt: today },
              },
            },
            { $count: "count" },
          ],
          totalValue: [
            {
              $group: {
                _id: null,
                total: {
                  $sum: {
                    $multiply: ["$quantity.available", "$cost.unitCost"],
                  },
                },
              },
            },
          ],
          statusDistribution: [
            { $group: { _id: "$status", count: { $sum: 1 } } },
          ],
        },
      },
    ]);

    res.status(200).json({
      success: true,
      data: {
        totalItems: stats[0].totalItems[0]?.count || 0,
        lowStock: stats[0].lowStock[0]?.count || 0,
        expiringSoon: stats[0].expiringSoon[0]?.count || 0,
        expired: stats[0].expired[0]?.count || 0,
        totalValue: stats[0].totalValue[0]?.total || 0,
        statusDistribution: stats[0].statusDistribution,
      },
    });
  } catch (error) {
    console.error("Get inventory stats error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving inventory statistics",
    });
  }
};

// @desc    Update stock quantity
// @route   PUT /api/inventory/:id/stock
// @access  Private (Pharmacist, Admin)
exports.updateStock = async (req, res, next) => {
  try {
    const { quantityChange, reason } = req.body;

    if (!quantityChange || !reason) {
      return res.status(400).json({
        success: false,
        message: "Please provide quantity change and reason",
      });
    }

    let item = await Inventory.findById(req.params.id);

    if (!item) {
      return res.status(404).json({
        success: false,
        message: "Inventory item not found",
      });
    }

    // Update available quantity
    item.quantity.available += quantityChange;

    // Update current quantity
    item.quantity.current += quantityChange;

    // Add to stock movement history
    item.stockMovement.push({
      type: quantityChange > 0 ? "In" : "Out",
      quantity: Math.abs(quantityChange),
      reason,
      performedBy: req.user.id,
      date: new Date(),
    });

    item.updatedBy = req.user.id;

    await item.save();

    res.status(200).json({
      success: true,
      message: "Stock updated successfully",
      data: item,
    });
  } catch (error) {
    console.error("Update stock error:", error);
    res.status(500).json({
      success: false,
      message: "Server error updating stock",
    });
  }
};
