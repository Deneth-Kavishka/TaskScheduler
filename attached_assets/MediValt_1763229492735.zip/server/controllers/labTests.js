const LabTest = require("../models/LabTest");
const Patient = require("../models/Patient");
const User = require("../models/User");
const ErrorResponse = require("../utils/errorResponse");

// @desc    Get all lab tests
// @route   GET /api/lab-tests
// @access  Private (Doctor, LabTechnician, Nurse, Admin)
exports.getLabTests = async (req, res, next) => {
  try {
    let query = {};

    // Role-based filtering
    if (req.user.role === "Doctor") {
      query.orderedBy = req.user.id;
    } else if (req.user.role === "Patient") {
      const patient = await Patient.findOne({ user: req.user.id });
      if (patient) {
        query.patient = patient._id;
      } else {
        return res.status(404).json({
          success: false,
          message: "Patient profile not found",
        });
      }
    } else if (req.user.role === "LabTechnician") {
      query["tests.performedBy"] = req.user.id;
    }

    // Filter by patient
    if (req.query.patient) {
      query.patient = req.query.patient;
    }

    // Filter by doctor
    if (req.query.orderedBy) {
      query.orderedBy = req.query.orderedBy;
    }

    // Filter by category
    if (req.query.category) {
      query.category = req.query.category;
    }

    // Filter by status
    if (req.query.status) {
      query.status = req.query.status;
    }

    // Filter by date range
    if (req.query.startDate && req.query.endDate) {
      query["sampleCollection.collectionDate"] = {
        $gte: new Date(req.query.startDate),
        $lte: new Date(req.query.endDate),
      };
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await LabTest.countDocuments(query);

    // Execute query
    const labTests = await LabTest.find(query)
      .populate({
        path: "patient",
        populate: {
          path: "user",
          select: "firstName lastName email phone nic",
        },
      })
      .populate("orderedBy", "firstName lastName specialization")
      .populate("tests.performedBy", "firstName lastName")
      .populate("tests.verifiedBy", "firstName lastName")
      .populate("createdBy", "firstName lastName role")
      .sort({ createdAt: -1 })
      .skip(startIndex)
      .limit(limit);

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit,
      };
    }

    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit,
      };
    }

    res.status(200).json({
      success: true,
      count: labTests.length,
      pagination,
      data: labTests,
    });
  } catch (error) {
    console.error("Get lab tests error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving lab tests",
    });
  }
};

// @desc    Get single lab test
// @route   GET /api/lab-tests/:id
// @access  Private (Doctor, LabTechnician, Nurse, Admin, Patient)
exports.getLabTest = async (req, res, next) => {
  try {
    const labTest = await LabTest.findById(req.params.id)
      .populate({
        path: "patient",
        populate: {
          path: "user",
          select: "firstName lastName email phone nic dateOfBirth gender",
        },
      })
      .populate("orderedBy", "firstName lastName specialization email")
      .populate("tests.performedBy", "firstName lastName role")
      .populate("tests.verifiedBy", "firstName lastName role")
      .populate("createdBy", "firstName lastName role");

    if (!labTest) {
      return res.status(404).json({
        success: false,
        message: "Lab test not found",
      });
    }

    // Authorization check for patients
    if (req.user.role === "Patient") {
      const patient = await Patient.findOne({ user: req.user.id });
      if (!patient || labTest.patient.toString() !== patient._id.toString()) {
        return res.status(403).json({
          success: false,
          message: "Not authorized to access this lab test",
        });
      }
    }

    res.status(200).json({
      success: true,
      data: labTest,
    });
  } catch (error) {
    console.error("Get lab test error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving lab test",
    });
  }
};

// @desc    Create new lab test order
// @route   POST /api/lab-tests
// @access  Private (Doctor)
exports.createLabTest = async (req, res, next) => {
  try {
    // Add ordering doctor
    req.body.orderedBy = req.user.id;
    req.body.createdBy = req.user.id;

    // Verify patient exists
    const patient = await Patient.findById(req.body.patient);
    if (!patient) {
      return res.status(404).json({
        success: false,
        message: "Patient not found",
      });
    }

    // Generate test ID
    const testCount = await LabTest.countDocuments();
    req.body.testId = `LAB${String(testCount + 1).padStart(6, "0")}`;

    const labTest = await LabTest.create(req.body);

    // Populate and return
    const populatedLabTest = await LabTest.findById(labTest._id)
      .populate({
        path: "patient",
        populate: {
          path: "user",
          select: "firstName lastName email phone",
        },
      })
      .populate("orderedBy", "firstName lastName specialization");

    res.status(201).json({
      success: true,
      message: "Lab test order created successfully",
      data: populatedLabTest,
    });
  } catch (error) {
    console.error("Create lab test error:", error);
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(", "),
      });
    }
    res.status(500).json({
      success: false,
      message: "Server error creating lab test order",
    });
  }
};

// @desc    Update lab test
// @route   PUT /api/lab-tests/:id
// @access  Private (LabTechnician, Doctor, Admin)
exports.updateLabTest = async (req, res, next) => {
  try {
    let labTest = await LabTest.findById(req.params.id);

    if (!labTest) {
      return res.status(404).json({
        success: false,
        message: "Lab test not found",
      });
    }

    labTest = await LabTest.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    })
      .populate({
        path: "patient",
        populate: {
          path: "user",
          select: "firstName lastName email phone",
        },
      })
      .populate("orderedBy", "firstName lastName specialization")
      .populate("tests.performedBy", "firstName lastName");

    res.status(200).json({
      success: true,
      message: "Lab test updated successfully",
      data: labTest,
    });
  } catch (error) {
    console.error("Update lab test error:", error);
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(", "),
      });
    }
    res.status(500).json({
      success: false,
      message: "Server error updating lab test",
    });
  }
};

// @desc    Add test results
// @route   PUT /api/lab-tests/:id/results
// @access  Private (LabTechnician, Admin)
exports.addTestResults = async (req, res, next) => {
  try {
    const { testIndex, result, notes } = req.body;

    let labTest = await LabTest.findById(req.params.id);

    if (!labTest) {
      return res.status(404).json({
        success: false,
        message: "Lab test not found",
      });
    }

    if (testIndex === undefined || !labTest.tests[testIndex]) {
      return res.status(400).json({
        success: false,
        message: "Invalid test index",
      });
    }

    // Update test result
    labTest.tests[testIndex].result = result;
    labTest.tests[testIndex].status = "Completed";
    labTest.tests[testIndex].performedBy = req.user.id;
    labTest.tests[testIndex].completedDate = new Date();
    if (notes) {
      labTest.tests[testIndex].notes = notes;
    }

    // Check if all tests are completed
    const allCompleted = labTest.tests.every(
      (test) => test.status === "Completed"
    );
    if (allCompleted) {
      labTest.status = "Completed";
    }

    await labTest.save();

    labTest = await LabTest.findById(req.params.id)
      .populate("tests.performedBy", "firstName lastName")
      .populate("patient")
      .populate("orderedBy");

    res.status(200).json({
      success: true,
      message: "Test results added successfully",
      data: labTest,
    });
  } catch (error) {
    console.error("Add test results error:", error);
    res.status(500).json({
      success: false,
      message: "Server error adding test results",
    });
  }
};

// @desc    Get lab test statistics
// @route   GET /api/lab-tests/stats
// @access  Private (LabTechnician, Doctor, Admin)
exports.getLabTestStats = async (req, res, next) => {
  try {
    const stats = await LabTest.aggregate([
      {
        $facet: {
          totalTests: [{ $count: "count" }],
          statusDistribution: [
            { $group: { _id: "$status", count: { $sum: 1 } } },
          ],
          categoryDistribution: [
            { $group: { _id: "$category", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
          ],
          priorityDistribution: [
            { $group: { _id: "$priority", count: { $sum: 1 } } },
          ],
          monthlyTrend: [
            {
              $group: {
                _id: {
                  year: { $year: "$createdAt" },
                  month: { $month: "$createdAt" },
                },
                count: { $sum: 1 },
              },
            },
            { $sort: { "_id.year": -1, "_id.month": -1 } },
            { $limit: 12 },
          ],
        },
      },
    ]);

    res.status(200).json({
      success: true,
      data: {
        totalTests: stats[0].totalTests[0]?.count || 0,
        statusDistribution: stats[0].statusDistribution,
        categoryDistribution: stats[0].categoryDistribution,
        priorityDistribution: stats[0].priorityDistribution,
        monthlyTrend: stats[0].monthlyTrend,
      },
    });
  } catch (error) {
    console.error("Get lab test stats error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving lab test statistics",
    });
  }
};
