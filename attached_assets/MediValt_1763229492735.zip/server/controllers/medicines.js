const Medicine = require("../models/Medicine");
const Inventory = require("../models/Inventory");
const ErrorResponse = require("../utils/errorResponse");

// @desc    Get all medicines
// @route   GET /api/medicines
// @access  Private (Doctor, Pharmacist, Nurse, Admin)
exports.getMedicines = async (req, res, next) => {
  try {
    let query = {};

    // Search functionality
    if (req.query.search) {
      const searchRegex = new RegExp(req.query.search, "i");
      query.$or = [
        { name: searchRegex },
        { genericName: searchRegex },
        { drugClass: searchRegex },
        { manufacturer: searchRegex },
      ];
    }

    // Filter by drug class
    if (req.query.drugClass) {
      query.drugClass = req.query.drugClass;
    }

    // Filter by controlled substance
    if (req.query.controlledSubstance !== undefined) {
      query.controlledSubstance = req.query.controlledSubstance === "true";
    }

    // Filter by FDA approval
    if (req.query.fdaApproval !== undefined) {
      query.fdaApproval = req.query.fdaApproval === "true";
    }

    // Filter by active status
    if (req.query.status) {
      query.status = req.query.status;
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Medicine.countDocuments(query);

    // Execute query
    const medicines = await Medicine.find(query)
      .populate("createdBy", "firstName lastName role")
      .populate("updatedBy", "firstName lastName role")
      .sort({ name: 1 })
      .skip(startIndex)
      .limit(limit);

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
      pagination.next = {
        page: page + 1,
        limit,
      };
    }

    if (startIndex > 0) {
      pagination.prev = {
        page: page - 1,
        limit,
      };
    }

    res.status(200).json({
      success: true,
      count: medicines.length,
      pagination,
      data: medicines,
    });
  } catch (error) {
    console.error("Get medicines error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving medicines",
    });
  }
};

// @desc    Get single medicine
// @route   GET /api/medicines/:id
// @access  Private (Doctor, Pharmacist, Nurse, Admin)
exports.getMedicine = async (req, res, next) => {
  try {
    const medicine = await Medicine.findById(req.params.id)
      .populate("createdBy", "firstName lastName role")
      .populate("updatedBy", "firstName lastName role");

    if (!medicine) {
      return res.status(404).json({
        success: false,
        message: "Medicine not found",
      });
    }

    // Get inventory information for this medicine
    const inventory = await Inventory.find({ medicine: medicine._id })
      .select("batchNumber lotNumber quantity expiryDate status")
      .sort({ expiryDate: 1 });

    res.status(200).json({
      success: true,
      data: {
        ...medicine.toObject(),
        inventory,
      },
    });
  } catch (error) {
    console.error("Get medicine error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving medicine",
    });
  }
};

// @desc    Create new medicine
// @route   POST /api/medicines
// @access  Private (Pharmacist, Admin)
exports.createMedicine = async (req, res, next) => {
  try {
    // Add user to req.body
    req.body.createdBy = req.user.id;
    req.body.updatedBy = req.user.id;

    // Generate medicine ID
    const medicineCount = await Medicine.countDocuments();
    req.body.medicineId = `MED${String(medicineCount + 1).padStart(6, "0")}`;

    const medicine = await Medicine.create(req.body);

    res.status(201).json({
      success: true,
      message: "Medicine created successfully",
      data: medicine,
    });
  } catch (error) {
    console.error("Create medicine error:", error);
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(", "),
      });
    }
    res.status(500).json({
      success: false,
      message: "Server error creating medicine",
    });
  }
};

// @desc    Update medicine
// @route   PUT /api/medicines/:id
// @access  Private (Pharmacist, Admin)
exports.updateMedicine = async (req, res, next) => {
  try {
    let medicine = await Medicine.findById(req.params.id);

    if (!medicine) {
      return res.status(404).json({
        success: false,
        message: "Medicine not found",
      });
    }

    // Add updated by user
    req.body.updatedBy = req.user.id;

    medicine = await Medicine.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    }).populate("updatedBy", "firstName lastName role");

    res.status(200).json({
      success: true,
      message: "Medicine updated successfully",
      data: medicine,
    });
  } catch (error) {
    console.error("Update medicine error:", error);
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(", "),
      });
    }
    res.status(500).json({
      success: false,
      message: "Server error updating medicine",
    });
  }
};

// @desc    Delete medicine
// @route   DELETE /api/medicines/:id
// @access  Private (Admin)
exports.deleteMedicine = async (req, res, next) => {
  try {
    const medicine = await Medicine.findById(req.params.id);

    if (!medicine) {
      return res.status(404).json({
        success: false,
        message: "Medicine not found",
      });
    }

    // Check if medicine is used in any inventory
    const inventoryCount = await Inventory.countDocuments({
      medicine: medicine._id,
    });

    if (inventoryCount > 0) {
      return res.status(400).json({
        success: false,
        message:
          "Cannot delete medicine with existing inventory. Please remove all inventory entries first.",
      });
    }

    await medicine.deleteOne();

    res.status(200).json({
      success: true,
      message: "Medicine deleted successfully",
      data: {},
    });
  } catch (error) {
    console.error("Delete medicine error:", error);
    res.status(500).json({
      success: false,
      message: "Server error deleting medicine",
    });
  }
};

// @desc    Get medicine statistics
// @route   GET /api/medicines/stats
// @access  Private (Pharmacist, Admin)
exports.getMedicineStats = async (req, res, next) => {
  try {
    const stats = await Medicine.aggregate([
      {
        $facet: {
          totalMedicines: [{ $count: "count" }],
          controlledSubstances: [
            { $match: { controlledSubstance: true } },
            { $count: "count" },
          ],
          drugClassDistribution: [
            { $group: { _id: "$drugClass", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 10 },
          ],
          routeDistribution: [
            { $group: { _id: "$routeOfAdministration", count: { $sum: 1 } } },
            { $sort: { count: -1 } },
          ],
          statusDistribution: [
            { $group: { _id: "$status", count: { $sum: 1 } } },
          ],
        },
      },
    ]);

    res.status(200).json({
      success: true,
      data: {
        totalMedicines: stats[0].totalMedicines[0]?.count || 0,
        controlledSubstances: stats[0].controlledSubstances[0]?.count || 0,
        drugClassDistribution: stats[0].drugClassDistribution,
        routeDistribution: stats[0].routeDistribution,
        statusDistribution: stats[0].statusDistribution,
      },
    });
  } catch (error) {
    console.error("Get medicine stats error:", error);
    res.status(500).json({
      success: false,
      message: "Server error retrieving medicine statistics",
    });
  }
};
