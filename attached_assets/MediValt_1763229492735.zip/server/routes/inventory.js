const express = require("express");
const {
  getInventoryItems,
  getInventoryItem,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  getInventoryStats,
  updateStock,
} = require("../controllers/inventory");

const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

// All routes are protected
router.use(protect);

// Statistics route (must be before /:id routes)
router.get("/stats", authorize("Pharmacist", "Admin"), getInventoryStats);

// Main CRUD routes
router
  .route("/")
  .get(authorize("Pharmacist", "Admin", "Doctor"), getInventoryItems)
  .post(authorize("Pharmacist", "Admin"), createInventoryItem);

router
  .route("/:id")
  .get(authorize("Pharmacist", "Admin", "Doctor"), getInventoryItem)
  .put(authorize("Pharmacist", "Admin"), updateInventoryItem)
  .delete(authorize("Admin"), deleteInventoryItem);

// Stock management
router.put("/:id/stock", authorize("Pharmacist", "Admin"), updateStock);

module.exports = router;
