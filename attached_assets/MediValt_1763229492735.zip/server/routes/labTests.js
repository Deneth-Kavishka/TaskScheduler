const express = require("express");
const {
  getLabTests,
  getLabTest,
  createLabTest,
  updateLabTest,
  addTestResults,
  getLabTestStats,
} = require("../controllers/labTests");

const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

// All routes are protected
router.use(protect);

// Statistics route (must be before /:id routes)
router.get(
  "/stats",
  authorize("Doctor", "LabTechnician", "Admin"),
  getLabTestStats
);

// Main CRUD routes
router
  .route("/")
  .get(getLabTests) // All authenticated users can view (filtered by role)
  .post(authorize("Doctor"), createLabTest);

router
  .route("/:id")
  .get(getLabTest) // All authenticated users can view specific tests (with authorization checks)
  .put(authorize("LabTechnician", "Doctor", "Admin"), updateLabTest);

// Test results
router.put(
  "/:id/results",
  authorize("LabTechnician", "Admin"),
  addTestResults
);

module.exports = router;
