const express = require("express");
const {
  getMedicines,
  getMedicine,
  createMedicine,
  updateMedicine,
  deleteMedicine,
  getMedicineStats,
} = require("../controllers/medicines");

const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

// All routes are protected
router.use(protect);

// Statistics route (must be before /:id routes)
router.get(
  "/stats",
  authorize("Pharmacist", "Admin"),
  getMedicineStats
);

// Main CRUD routes
router
  .route("/")
  .get(authorize("Doctor", "Pharmacist", "Nurse", "Admin"), getMedicines)
  .post(authorize("Pharmacist", "Admin"), createMedicine);

router
  .route("/:id")
  .get(authorize("Doctor", "Pharmacist", "Nurse", "Admin"), getMedicine)
  .put(authorize("Pharmacist", "Admin"), updateMedicine)
  .delete(authorize("Admin"), deleteMedicine);

module.exports = router;
