const mongoose = require("mongoose");

const PaymentSchema = new mongoose.Schema(
  {
    paymentId: {
      type: String,
      unique: true,
      required: true,
    },

    // Bill Reference
    bill: {
      type: mongoose.Schema.ObjectId,
      ref: "Bill",
      required: [true, "Bill reference is required"],
    },

    // Payment Details
    paymentDate: {
      type: Date,
      default: Date.now,
      required: true,
    },

    amount: {
      type: Number,
      required: [true, "Payment amount is required"],
      min: [0, "Payment amount cannot be negative"],
    },

    // Payment Method
    paymentMethod: {
      type: String,
      required: [true, "Payment method is required"],
      enum: ["Cash", "Credit Card", "Debit Card", "Insurance", "Bank Transfer", "Mobile Payment", "Check"],
    },

    // Transaction Details
    transactionId: {
      type: String,
      unique: true,
      sparse: true,
    },

    transactionReference: String,

    // Status
    status: {
      type: String,
      enum: ["Pending", "Completed", "Failed", "Refunded"],
      default: "Completed",
    },

    // Card Details (if applicable) - last 4 digits only
    cardDetails: {
      lastFourDigits: String,
      cardType: {
        type: String,
        enum: ["Visa", "MasterCard", "AmEx", "Discover"],
      },
    },

    // Notes
    notes: String,
    receiptNumber: String,

    // Refund Information
    refund: {
      isRefunded: {
        type: Boolean,
        default: false,
      },
      refundDate: Date,
      refundAmount: Number,
      refundReason: String,
      refundedBy: {
        type: mongoose.Schema.ObjectId,
        ref: "User",
      },
    },

    // Audit Trail
    processedBy: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Payment", PaymentSchema);
