const mongoose = require("mongoose");

const NotificationSchema = new mongoose.Schema(
  {
    notificationId: {
      type: String,
      unique: true,
      required: true,
    },

    // Recipient
    recipient: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
      required: [true, "Recipient is required"],
    },

    // Notification Type
    type: {
      type: String,
      required: [true, "Notification type is required"],
      enum: [
        "Appointment Reminder",
        "Appointment Cancelled",
        "Appointment Rescheduled",
        "Lab Results Ready",
        "Prescription Ready",
        "Bill Payment Due",
        "Bill Payment Received",
        "Low Stock Alert",
        "Medicine Expiry Alert",
        "System Alert",
        "General",
      ],
    },

    // Priority
    priority: {
      type: String,
      enum: ["Low", "Normal", "High", "Urgent"],
      default: "Normal",
    },

    // Content
    title: {
      type: String,
      required: [true, "Notification title is required"],
      maxlength: [200, "Title cannot be more than 200 characters"],
    },

    message: {
      type: String,
      required: [true, "Notification message is required"],
      maxlength: [1000, "Message cannot be more than 1000 characters"],
    },

    // Reference
    referenceType: {
      type: String,
      enum: ["Appointment", "Prescription", "LabTest", "Bill", "Inventory", "MedicalRecord", "None"],
      default: "None",
    },

    referenceId: {
      type: mongoose.Schema.ObjectId,
    },

    // Delivery Channels
    channels: {
      inApp: {
        type: Boolean,
        default: true,
      },
      email: {
        type: Boolean,
        default: false,
      },
      sms: {
        type: Boolean,
        default: false,
      },
    },

    // Status
    status: {
      type: String,
      enum: ["Unread", "Read", "Archived"],
      default: "Unread",
    },

    readAt: Date,

    // Scheduled Delivery
    scheduledFor: {
      type: Date,
      default: Date.now,
    },

    sentAt: Date,

    // Email/SMS Details
    emailSent: {
      type: Boolean,
      default: false,
    },

    smsSent: {
      type: Boolean,
      default: false,
    },

    // Action URL
    actionUrl: String,

    // Audit
    createdBy: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
  }
);

// Index for efficient querying
NotificationSchema.index({ recipient: 1, status: 1, createdAt: -1 });
NotificationSchema.index({ scheduledFor: 1, sentAt: 1 });

module.exports = mongoose.model("Notification", NotificationSchema);
