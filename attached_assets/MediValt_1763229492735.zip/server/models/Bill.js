const mongoose = require("mongoose");

const BillSchema = new mongoose.Schema(
  {
    billId: {
      type: String,
      unique: true,
      required: true,
    },

    // Patient Information
    patient: {
      type: mongoose.Schema.ObjectId,
      ref: "Patient",
      required: [true, "Patient is required"],
    },

    // Bill Details
    billDate: {
      type: Date,
      default: Date.now,
      required: true,
    },

    dueDate: {
      type: Date,
      required: true,
    },

    // Line Items
    items: [
      {
        description: {
          type: String,
          required: true,
        },
        type: {
          type: String,
          enum: [
            "Consultation",
            "Procedure",
            "Lab Test",
            "Medication",
            "Room Charge",
            "Other",
          ],
          required: true,
        },
        referenceId: mongoose.Schema.ObjectId,
        quantity: {
          type: Number,
          default: 1,
          min: 1,
        },
        unitPrice: {
          type: Number,
          required: true,
          min: 0,
        },
        discount: {
          type: Number,
          default: 0,
          min: 0,
        },
        tax: {
          type: Number,
          default: 0,
          min: 0,
        },
        total: {
          type: Number,
          required: true,
        },
      },
    ],

    // Totals
    subtotal: {
      type: Number,
      required: true,
      min: 0,
    },

    totalDiscount: {
      type: Number,
      default: 0,
      min: 0,
    },

    totalTax: {
      type: Number,
      default: 0,
      min: 0,
    },

    totalAmount: {
      type: Number,
      required: true,
      min: 0,
    },

    paidAmount: {
      type: Number,
      default: 0,
      min: 0,
    },

    balanceAmount: {
      type: Number,
      required: true,
      min: 0,
    },

    // Status
    status: {
      type: String,
      enum: ["Pending", "Partial", "Paid", "Overdue", "Cancelled"],
      default: "Pending",
    },

    // Payment Information
    payments: [
      {
        type: mongoose.Schema.ObjectId,
        ref: "Payment",
      },
    ],

    // Insurance
    insurance: {
      applied: {
        type: Boolean,
        default: false,
      },
      provider: String,
      claimNumber: String,
      coveredAmount: {
        type: Number,
        default: 0,
      },
      patientResponsibility: {
        type: Number,
        default: 0,
      },
    },

    // Notes
    notes: String,

    // Audit Trail
    createdBy: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
      required: true,
    },

    updatedBy: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
  }
);

// Calculate totals before saving
BillSchema.pre("save", function (next) {
  // Calculate item totals
  this.items.forEach((item) => {
    const baseAmount = item.quantity * item.unitPrice;
    const discountAmount = (baseAmount * item.discount) / 100;
    const taxableAmount = baseAmount - discountAmount;
    const taxAmount = (taxableAmount * item.tax) / 100;
    item.total = taxableAmount + taxAmount;
  });

  // Calculate bill totals
  this.subtotal = this.items.reduce((sum, item) => {
    return sum + item.quantity * item.unitPrice;
  }, 0);

  this.totalDiscount = this.items.reduce((sum, item) => {
    const baseAmount = item.quantity * item.unitPrice;
    return sum + (baseAmount * item.discount) / 100;
  }, 0);

  this.totalTax = this.items.reduce((sum, item) => {
    const baseAmount = item.quantity * item.unitPrice;
    const discountAmount = (baseAmount * item.discount) / 100;
    const taxableAmount = baseAmount - discountAmount;
    return sum + (taxableAmount * item.tax) / 100;
  }, 0);

  this.totalAmount = this.items.reduce((sum, item) => sum + item.total, 0);

  this.balanceAmount = this.totalAmount - this.paidAmount;

  // Update status based on payment
  if (this.balanceAmount <= 0) {
    this.status = "Paid";
  } else if (this.paidAmount > 0) {
    this.status = "Partial";
  } else if (new Date() > this.dueDate && this.balanceAmount > 0) {
    this.status = "Overdue";
  }

  next();
});

module.exports = mongoose.model("Bill", BillSchema);
