# MediVault - Healthcare Management System

## Overview
MediVault is a professional healthcare management system built with the MERN stack (MongoDB, Express, React/Next.js, Node.js). This application provides comprehensive features for managing patients, appointments, prescriptions, medical records, and inventory.

## Project Status
**Migration Status**: Successfully migrated from Vercel to Replit (November 15, 2025)
**Current State**: Application is running and accessible on Replit with frontend and backend properly configured

## Architecture

### Frontend
- **Technology**: Next.js 15.5.3 with React 19
- **Location**: `/frontend` directory
- **Port**: 5000 (bound to 0.0.0.0 for Replit compatibility)
- **Key Features**:
  - Patient management dashboard
  - Authentication (login/register)
  - Medical records interface
  - Appointment scheduling
  - Responsive UI with Tailwind CSS
  - React Query for data fetching
  - Zustand for state management

### Backend
- **Technology**: Express.js with Node.js
- **Location**: Root directory (`server.js`) and `/server` folder
- **Port**: 3000 (backend API)
- **Key Features**:
  - RESTful API endpoints
  - JWT authentication
  - Role-based access control
  - Data encryption for sensitive medical information
  - QR code generation for patient records
  - Rate limiting and security middleware (Helmet, CORS, XSS protection)
  - MongoDB with Mongoose ODM

## Replit Configuration

### Node.js Version
- **Current**: Node.js 20.x
- **Required**: Node.js >= 18.18.0 (for Next.js 15 compatibility)

### Workflow
- **Name**: MediVault
- **Command**: `bash start.sh`
- **Description**: Starts both backend (Express) and frontend (Next.js) concurrently

### Deployment Configuration
- **Type**: VM (for persistent connections and WebSocket support)
- **Build**: `cd frontend && npm install && npm run build`
- **Run**: `node server.js & cd frontend && npm run start`

## Environment Variables

### Required Secrets (Configured in Replit Secrets)
- `MONGODB_URI` - MongoDB connection string
- `JWT_SECRET` - Secret for JWT token signing
- `CRYPTO_SECRET` - Secret for encrypting sensitive medical data
- `QR_CODE_SECRET` - Secret for QR code signing

### Optional Environment Variables
- `NODE_ENV` - Environment mode (development/production)
- `BACKEND_PORT` - Backend server port (default: 3000)
- `JWT_EXPIRE` - JWT token expiration (default: 30d)
- `EMAIL_HOST` - SMTP host for email notifications
- `EMAIL_PORT` - SMTP port
- `EMAIL_USER` - Email username
- `EMAIL_PASS` - Email password

## Recent Changes (November 15, 2025)

### Migration to Replit - Completed Successfully
1. **Upgraded Node.js**: From v16 to v20 for Next.js 15 compatibility
2. **Port Configuration**:
   - Frontend: Configured to run on port 5000 with 0.0.0.0 binding
   - Backend: Changed to port 3000 (environment variable: BACKEND_PORT)
3. **Next.js Configuration**:
   - Configured `allowedOrigins` with strict Replit domain validation
   - Added `outputFileTracingRoot` to resolve workspace warnings
   - Removed `--turbopack` flag for better compatibility
4. **Security Enhancements**:
   - Implemented strict CORS with hostname validation for .replit.dev domains
   - Re-enabled rate limiting on all API endpoints (100 req/15min general, stricter for auth)
   - Removed request body logging to protect PHI/sensitive data
   - Configured Next.js server actions with explicit allowed origins
5. **Workflow Setup**: Created `start.sh` to launch both servers concurrently
6. **Deployment Config**: Configured for VM deployment with proper build and run commands

### Important Notes for Production
- Current rate limiting uses in-memory store (resets on restart). For production, consider Redis/Upstash for distributed rate limiting
- MONGODB_URI must point to a cloud MongoDB instance (MongoDB Atlas recommended). Local MongoDB will not work in Replit
- Set NODE_ENV=production for production deployments to ensure proper environment-specific behavior

## Database

### Current Setup
- **Database**: MongoDB (cloud-based recommended)
- **ORM**: Mongoose
- **Models**: User, Patient, Appointment, Prescription, MedicalRecord, Medicine, Inventory, LabTest

### Database Connection Notes
- The application requires a cloud MongoDB instance (MongoDB Atlas recommended)
- Local MongoDB (localhost:27017) will not work in the Replit environment
- Connection string must be added to MONGODB_URI secret

## API Endpoints

### Authentication
- POST `/api/auth/register` - User registration
- POST `/api/auth/login` - User login
- GET `/api/auth/me` - Get current user

### Core Features
- `/api/patients` - Patient management
- `/api/appointments` - Appointment scheduling
- `/api/prescriptions` - Prescription management
- `/api/medical-records` - Medical records
- `/api/medicines` - Medicine catalog
- `/api/inventory` - Inventory management
- `/api/lab-tests` - Laboratory tests

## File Structure
```
medivault/
├── frontend/                 # Next.js application
│   ├── src/
│   │   ├── app/             # Next.js app router pages
│   │   ├── components/      # React components
│   │   ├── contexts/        # React contexts
│   │   └── lib/             # Utilities and helpers
│   ├── package.json
│   └── next.config.ts
├── server/                   # Backend application
│   ├── config/              # Database configuration
│   ├── controllers/         # Route controllers
│   ├── middleware/          # Express middleware
│   ├── models/              # Mongoose models
│   ├── routes/              # API routes
│   └── utils/               # Utility functions
├── server.js                # Main server entry point
├── start.sh                 # Startup script
└── package.json             # Root package.json
```

## Security Features
- Helmet.js for HTTP headers security
- CORS configuration for cross-origin requests
- Express Rate Limiting
- MongoDB sanitization against NoSQL injection
- XSS attack prevention
- Data encryption for sensitive information
- JWT-based authentication
- Input validation with express-validator

## Development Notes
- Frontend hot-reloads automatically during development
- Backend uses nodemon for auto-restart during development
- All sensitive data is encrypted before storage
- QR codes are generated for patient identification
- Real-time updates available via Socket.IO (configured on port 5001)

## User Preferences
None specified yet.
